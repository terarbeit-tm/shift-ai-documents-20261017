---
name: shift-ai-webinar-slidegen
description: "Create SHIFT AI webinar slide images with built-in imagegen in the fixed Large Standard design: white, muted magenta/purple, business-scene isometric illustrations, large Japanese Gothic text. Use for SHIFT AI raster slides, not Teramachi-brand slides or editable decks."
---

# SHIFT AI Webinar Slidegen

Generate one 16:9 raster slide per image using built-in imagegen. Use a true 16:9 canvas, such as 1920×1080; 1792×1024 is not 16:9. Do not substitute editable decks or deterministic renderers unless explicitly requested.

## Source boundaries: visible text versus production notes

- Establish the visible-text boundary before preserving content or assigning typography. Explicit user instructions and fields such as `表示`, `表示テキスト`, or `画面に表示` determine what belongs on the canvas.
- In a structured slide outline, a level-three Markdown heading outside a code block such as `### [スライド 13] 理由は、どれだと思いますか？` is a management heading. Do not render that entire heading line, including its wording after the slide identifier. The same rule applies to equivalent identifiers such as `[P13]`, `[S13]`, or `P013｜見出し` when used as slide-management headings. Recognize this by the `###` heading syntax and its role in the outline, not by editor color.
- When such a management heading is followed by a fenced display-text block and `備考`, render only the display block's contents. Markdown fences and separator rules are formatting syntax, not extra visible text. A `###` sequence inside the display block is source text and is not excluded by this outside-heading rule.
- In that format, the first line of the display block normally serves as the visible title or main question; do not prepend the outside heading or invent a second title. A slide may use a single prominent statement instead of a separate title. If the user explicitly wants the outside heading displayed, include it in the confirmed visible-text plan before generation.
- Speaker notes, delivery cues, audience-response handling, next-slide transitions, and layout/diagram instructions guide production but are not printed as wording. Follow applicable diagram instructions in those notes while keeping the notes themselves off the canvas.
- All source-completeness rules below apply to confirmed visible content and required visual meaning, not management headings or speaker-note prose. For other source formats, do not assume all headings are metadata or all fenced code is slide copy; preserve explicitly designated titles and code examples. If the display boundary is genuinely ambiguous, resolve it before generation.

## Fixed design: Large Standard

- White background, generous margins, bold modern Japanese Gothic typography (Noto Sans JP / Hiragino Sans), and dark navy text.
- Thin, subdued gradient divider from muted magenta `#b3446c` to muted purple `#70558f` below the title.
- Use muted rose-magenta `#b3446c` for human checkpoints, warnings, key contrasts, and conclusions; muted purple `#70558f` for structure, folders, tools, and secondary anchors. Keep these accents moderately dark and desaturated; do not boost their brightness or saturation or add glow.
- Prioritize screen-share readability: large text, bold hierarchy, clear panels, and strong contrast. Avoid tiny labels and narrow text areas.
- Use near-white, gray-tinted rose `#f7eff2` / purple `#f3f0f7` panels sparingly, with corner radius approximately 8px or less. Reserve solid accent colors for key text, thin rules, outlines, and small diagram nodes rather than large filled areas.
- Ordinary explanatory slides include a content-linked visual by default, even when the source supplies only text. Choose its form using the visual-planning rules below. Text-only slides are deliberate, recorded exceptions; they are not the default for a deck.
- Avoid dark full backgrounds, decorative blobs, stock-photo styling, busy gradients, heavy shadows, and invented branding.
- Requests such as “洗練させて” adjust spacing and alignment within this design; they do not select another mode.

## Fixed illustration style: business-scene isometric

- User-approved appearance references: [work scene](assets/reference_01_scene.png), [process](assets/reference_02_process.png), and [comparison](assets/reference_03_comparison.png). Inspect these when generating slide illustrations and use them as style references through supported imagegen inputs when helpful. Match the palette, people, object treatment, and restrained shadows; their large illustration scale and sparse text are not layout targets. These samples establish appearance only, not verified production dimensions or font sizes.
- Visual reference: [Tech Pic's business-scene illustrations](https://tech-pic.com/materials/1/1/456). Use the characteristics below as the self-contained style specification; retain this skill's palette and restrained effects.
- Draw clean, vector-like isometric business scenes that make the source-supported action visible: who is using a tool, reviewing a result, or collaborating. Include people, devices, and furniture only as needed to explain that action; for object-only concepts, use a standalone isometric object in the same style.
- Use one elevated three-quarter view with parallel receding axes at approximately 30 degrees; keep the viewing direction and degree of depth consistent across slides.
- Build recognizable, simplified forms with two or three flat tonal surfaces. Use white and light gray for the base, with the fixed muted magenta/purple accents. Allow restrained natural skin and hair tones for people; keep clothing and props within the deck palette. Distinguish edges mainly through adjacent color planes; any necessary outlines remain thin, subtle, and consistent.
- Use a common upper-left light direction. Ground shadows, when needed, are short, faint, and consistent. Avoid long dramatic shadows, glossy or photorealistic 3D, clay textures, detailed surface textures, and faceted low-poly styling.
- Keep detail density and proportions consistent for recurring objects such as PCs, desks, chairs, and folders. Use simplified professional figures with natural adult proportions, restrained facial detail, and readable poses and hand gestures. Keep recurring characters' appearance consistent across slides.
- Keep titles, explanations, diagram labels, arrows, and comparison panels horizontal and front-facing. Use isometric objects within the teaching diagram without tilting text or obscuring connections; preserve the layout and all source information.
- Apply this style to scene illustrations. A clear relationship diagram, table, checklist, or file tree can serve the visual purpose without an additional scene. Use typography alone only under a recorded text-only exception below.

## Visual planning: default and exceptions

Resolve every slide in the requested generation scope before the first image call. Do not wait for the user to point out missing diagrams.

| Source / teaching role | Default visual treatment |
|---|---|
| Process, comparison, hierarchy, branching choice, or before/after change | A relationship diagram showing the source-supported order, aligned differences, nesting, routes, or change. |
| Concept, benefit, use case, or other ordinary explanation | A compact content-linked isometric scene or object, or a relationship diagram when the source supports one. Show the actual source concept or action. |
| Table, checklist, file tree, or screen demonstration | An aligned visual structure or the specified screen frame; add a scene only when it explains something the structure does not. |
| Cover, section divider, short question, key statement, or closing | Typography alone is permitted when the wording is the focal point and a visual would add no teaching value. Record that reason. |

- Explicit user/source visual instructions are requirements from the first draft. A role name or the absence of a `描画` field does not cancel them. Preserve user restrictions on people, screenshots, placeholders, and reserved regions.
- Classify by the actual teaching content, not a convenient role tag. A list of benefits remains an ordinary explanation; adding bullets, checkboxes, or paragraph panels does not turn it into a structured-reference exemption. A closing slide that explains a process still needs that process visual.
- For an ordinary explanation, select a source-grounded visual instead of asking whether one is needed. Do not use “the source is text”, “no drawing instruction”, “little content”, “long text”, or a failed generation as a text-only exemption.
- Text-only exceptions must name the slide-specific teaching reason. Besides the typography-focused roles above, an explicitly requested text-only treatment or a complete dense reference whose readability would be harmed by artwork may justify an exception. During layout planning, first try a compact visual and a different grouping for dense explanations; do not exempt all explanations, profiles, or question slides by role alone.
- Required blank/reserved regions stay blank. They constrain that region, not the visual treatment of the entire slide: use the remaining usable area for the planned visual when required. Do not invent missing titles, photos, screenshots, or QR codes.
- A relationship diagram must expose the relationship. Colored paragraph cards, a title divider, and unrelated decorative icons do not satisfy it. A scene/object must depict the source concept or action; generic artwork does not satisfy the ordinary-explanation default.
- Keep visuals modest and text readable. If artwork causes crowding, simplify or reduce the artwork and rearrange the layout before splitting under the existing source-preservation rules. Do not silently remove the planned visual or shrink the body text.
- Review large empty areas in text-only exceptions: retain useful whitespace, but regroup or reposition content when the reading area looks unbalanced. Do not fill the space by enlarging type or artwork beyond the design rules.

Record the chosen visual, its source basis, placement, and any text-only exception in the production plan described in [production rules](references/production.md). The plan and prompt must agree; the rendered image must then pass the same requirement.

## Illustration scale and content balance

- Plan the space for complete source text and its required diagram before sizing the scene artwork. Specify a region or maximum bounding box for each illustration; keep the fixed typography tiers below. The illustration's drawing style stays consistent, while its size and placement adapt to content.
- For ordinary explanatory slides, start with individual scenes roughly 20–30% smaller than the appearance samples at equal displayed slide width. This is a planning guide, not a fixed ratio: a spatial relationship that is itself the teaching point may justify a larger scene. Keep the diagram's connections and labels prominent even when its scene artwork is smaller.
- With substantial explanation, place a compact scene beside a spacious text area. In processes and comparisons, align compact scene regions and reserve sufficient space for the complete explanations beside or below them. Reduce incidental props and simplify artwork before rearranging or splitting the slide; never shrink or omit source text to accommodate an illustration.
- Sparse content does not require enlarged artwork or added wording. Preserve whitespace. Check that the title and explanation remain the reader's first anchors, that illustrations support understanding without dominating ordinary explanatory slides, and that the required diagram stays clear.

## Fixed typography: three sizes across the deck

Use this exact design specification on a 1920×1080 canvas. Keep the same role-to-size mapping across every slide, including covers and section dividers; do not size text independently to fit each slide.

| Tier | Size | Role |
|---|---:|---|
| Large | 80 px | Slide title and a standalone section/closing headline |
| Medium | 56 px | Subtitle, source explanations, examples, benefit statements, and takeaway text |
| Small | 44 px | Short diagram labels and short category names only |

- Use Noto Sans JP Bold consistently, or one equivalent Japanese Gothic family for the entire deck if unavailable. These are the only three sizes: no intermediate sizes, oversized cover titles, or fourth footnote tier. At other output resolutions, scale all three sizes by the same canvas-width ratio; judge consistency at equal display size.
- Assign a tier to every visible text block before generation. Full source sentences and explanations remain Medium even when placed next to or below a diagram. Never demote them to Small to fit. Small is a readable label tier, not a caption/footnote tier.
- Wrap long titles at Large, widen or rearrange text areas, simplify the diagram, or split slides while preserving source content. Never shrink, horizontally compress, or delete text to fit. Do not enlarge sparse slides to fill whitespace.
- Avoid duplicating words inside an illustration and then repeating the same content in a small caption. Remove optional repeated diagram labels first and retain the complete source explanation at Medium in its own spacious area. Preserve any repetition explicitly required by the source/user.
- Keep outer margins at least 80 px, text-group gaps at least 32 px, and line height about 1.25–1.35 at the reference canvas size. Align comparable blocks to shared edges; preserve whitespace instead of filling it with extra text.
- Imagegen font sizes are requested design targets, not measurable font metadata or guaranteed pixel-exact output. Inspect rendered consistency across the deck; do not claim exact font-size verification from the prompt alone.

## Workflow

1. Read [production rules](references/production.md) before generating. Establish the visible-text boundary above, preserve that content, and resolve density before writing image prompts.
2. Complete the visual plan for every slide in scope using the defaults and exceptions above. Resolve the source-grounded objects/actions, relationships, and placement before writing image prompts. Check each prompt against that plan; a required visual cannot be left optional or absent. Keep the fixed design throughout the deck.
3. Generate one slide at a time with only this design's instructions. Do not include alternative brands, style modes, or conditional design branches in the image prompt.
4. Visually inspect every result against its visual plan and production QA before marking it accepted. Missing or irrelevant required visuals fail even when text and colors are correct. Correct the affected image, then review the deck's visual balance before final delivery. Save verified images when requested.

## Layout selection

Choose according to the teaching role, while retaining the fixed design:

- Concept shift: muted old idea, a simple arrow, and an emphasized new idea.
- Checklist: large checkboxes or source-provided numbered items in a clear panel.
- Process: connected steps with prominent human checkpoints.
- Comparison: two aligned columns with comparable rows.
- Choice: two or three routes with only source-provided labels and recommendations.
- Demo: a large blank screen frame and two or three source observation points.
- File tree: aligned indentation and legible filenames; no fake terminal screenshot.
- Reassurance or closing: fewer groups and a prominent main message.

Vary layouts when content warrants it. Keep the title largest, ordinarily at the upper left, with body placement determined by the selected layout. Follow the diagram requirements below; do not replace a required diagram with a text-only checklist.

## Diagram requirements

- Source completeness takes priority over diagram design. Carry forward every source point, example, caveat, condition, step, comparison row, and required visible text. Never omit or over-summarize content to make room for a diagram, and never silently move required slide content into speaker notes. A diagram supports the source; it does not replace information unless that information remains fully represented and readable.
- If the complete source and required diagram cannot fit legibly, simplify the diagram or split the slide while preserving all source content and traceability. If the user fixes the slide count and these requirements still conflict, ask which presentation constraint may change; never choose content loss on the user's behalf.
- An explicit request such as “図解を追加” or a diagram instruction in the slide source is a generation requirement within its specified scope, including the first draft; never downgrade it to “if helpful”. A deck-wide preference for visuals applies through the default and exception rules above; it is not a reason to omit visuals from ordinary explanations. Do not invent a percentage quota or require decorative illustrations on every slide.
- For source-supported processes, comparisons, hierarchies, branching choices, or before/after changes, show order with connected steps, differences with aligned comparison axes, hierarchy with nesting/branches, and choices with source-supported routes. An aligned table may provide the comparison structure. Do not invent causal links or recommended routes.
- When a diagram is selected or required, reserve an appropriate main content region for it and integrate the exact source text as readable labels or adjacent explanations. Do not first fill the canvas with paragraphs and then add a tiny visual in leftover space. Resolve excess density through the existing source-preserving splitting rules.
- Colored boxes containing paragraphs, isolated decorative icons, and bullets with no visible relationship do not satisfy a diagram request. Cards can serve as diagram nodes when their connections, grouping, or aligned contrasts explain the content.
- Apply the recorded text-only exceptions above instead of broadly classifying explanations as text-led. Tables and checklists may be complete visual structures without scene artwork. If a requested diagram is ambiguous, use a simple source-grounded representation; ask only when its meaning cannot be resolved without inventing content.

## Image prompt construction

Include only the resolved instructions for the current slide:

- A single 16:9 Japanese webinar slide.
- The fixed palette, divider, and readability requirements above. Repeat the 80/56/44 px typography specification (1920×1080 basis), common font family, and each text block’s assigned tier in every prompt. Do not merely say “large readable text”.
- For illustrations, include the fixed business-scene isometric treatment: source-supported action and participants when applicable, natural adult proportions and readable gestures, common viewing angle, flat tonal surfaces, muted palette, subtle edges, and short faint shadows. Keep all text front-facing and horizontal.
- Specify the text regions and each illustration's planned size or maximum bounding box according to the content-balance rules. Do not copy the appearance samples' large scene scale by default.
- One selected layout matching the production plan. For a diagram, specify source-grounded objects/labels, relationships, reading order, and placement. For a scene/object, specify the source concept/action and its compact bounds. Require that selected visual in the first image; do not say “if helpful” or “optional”. Only for a recorded text-only exception or a complete table/checklist/file-tree structure, explicitly request no added scene artwork.
- Exact Japanese visible text from the confirmed display boundary, clearly separated from design instructions. Do not pass management headings or speaker notes as additional wording to render.
- The selected source phrases to emphasize and the takeaway only when provided.
- No visible slide number, invented labels, logos, watermark, or fabricated UI.

Keep prompts concise. Resolve content splitting before the image call; never ask the image generator to decide how many slides to create.
