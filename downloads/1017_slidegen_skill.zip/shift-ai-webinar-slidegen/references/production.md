## Before Image Generation

Audit the slide outline before calling imagegen.

- Apply SKILL.md's source-boundary rules first. Record what will be displayed and what is management metadata, speaker notes, or drawing instructions. In the `### [スライド N] 見出し` + fenced display-block + notes format, the entire outside `###` heading line is management metadata; only the display block's contents become visible wording, and its first line normally supplies the visible title. Do not prepend the heading wording after the slide identifier. Apply equivalent slide-identifier formats by their management role, not to `###` text inside the display block.
- Apply SKILL.md's visual defaults and text-only exceptions to every slide in the requested generation scope. Ordinary explanations need a content-linked visual even without a drawing field. Record the visual plan below before calling imagegen; it is not extra visible slide text.
- Allocate complete text regions and scene artwork bounds using SKILL.md's content-balance rules. The approved samples establish drawing style, not mandatory illustration size; ordinary explanatory scenes start more compactly, with whitespace retained when content is sparse.
- Before the first image call, check each planned prompt against its visual plan. Include applicable user/source drawing instructions and the visual selected by default. “Add a diagram” alone is insufficient: specify what it depicts, its source basis, how its parts relate, and its bounds. A required visual must be mandatory in the prompt. Fix missing specifications before generating.

### Required visual plan

Use the existing project plan, or a compact Markdown table/JSON record. For each slide in scope, record:

- Slide ID and confirmed visible source.
- Visual mode: `diagram`, `scene/object`, `structured-reference`, or `text-only`.
- Source basis and concrete visual: objects/actions and exact labels; for relationships, connections, comparison axes, or nesting.
- Layout bounds for complete text and the selected visual. For `text-only`, record the specific permitted exception and teaching reason instead of visual bounds.
- Prompt check: the selected visual/exception is expressed consistently, with no optional wording for a required visual.
- After generation, visual QA: pass/fail and what is actually visible in the saved image. A prompt specification is not evidence of a rendered visual.

Do not begin generation with unresolved rows or blanket text-only exemptions. For multi-slide work, inspect an ordinary explanatory slide and a relationship slide early when those roles exist, before repeating their layouts across the deck. This is an internal quality check, not an additional user-approval step.

### Source completeness and density

- Preserve all confirmed visible source information and required visual meaning. Source completeness takes priority over diagram layout and visual simplicity. Never delete or over-summarize that content to make text larger or fit a diagram; never silently transfer required visible content to speaker notes. Management headings and speaker-note prose are outside this display scope.
- Before generation, map every source point, example, caveat, condition, step, and comparison row to visible text or a fully equivalent diagram element on the planned slide(s). Keep exact source wording where required. If any item has no destination, fix the plan before generating.
- If one slide is too dense, split it into multiple slide images and carry all content forward.
- When splitting a numbered slide, keep traceability in filenames and the internal plan with identifiers such as `Slide 11a` / `Slide 11b` or `Slide 11-1` / `Slide 11-2`; do not print these identifiers on the canvas.
- If the user explicitly requires a strict one-image-per-original-slide output and the source is dense, warn that readable font size and full content preservation conflict. Ask whether to split, compress wording without changing meaning, or switch to HTML/PPTX.
- Do not summarize away examples, caveats, steps, or comparison rows unless the user explicitly asks for a shorter version.
- Compression is allowed only when meaning is preserved. Deletion is not allowed.

Use these density thresholds as split signals:

- More than 120 Japanese characters in one slide.
- More than 3 bullet items.
- More than 3 main text groups.
- A comparison table larger than 2 columns x 3 rows.
- Any screen-share slide where body text would need to become small explanatory copy.

## Readability Rules

- Design for webinar screen sharing, not handout reading.
- Make the title the largest text element on the slide.
- Apply the fixed three-tier typography in SKILL.md to every visible block. Full source explanations use Medium, including text adjacent to diagrams; Small is for short labels only. Do not add a smaller caption tier.
- When a diagram duplicates a source explanation, remove optional duplicate labels and give the complete explanation a spacious Medium-size text area. Do not remove source information to reduce visual noise.
- Never solve crowding by shrinking text. Split the slide, simplify grouping, or remove decoration first.
- Never compress Japanese glyphs horizontally or force a long sentence into one narrow strip. Do not repeat a full source paragraph as small supporting text beneath a larger version. When a sentence needs emphasis, split it into two or three large reading blocks with generous line height.
- Prefer fewer large text groups over many small labels.
- Use at most 3 main text groups per generated slide.
- Keep each text group to 1-2 lines whenever possible.
- Avoid footnote-like body text. If a note must be preserved, move it to a follow-up slide rather than making it tiny.

## Deck invariants

- Keep one brand, palette, typography system, and divider treatment throughout a deck, including covers and section dividers. Vary layouts according to teaching role.
- Do not show slide numbers on the canvas; use them only in filenames and internal tracking.
- Only when the source includes a `▶` line, render it as a slim bottom takeaway bar. Never invent one.
- Do not invent claims, examples, numbers, labels, logos, URLs, QR codes, or detailed UI. Use blank placeholders when confirmed material is unavailable.
- Highlight only 1–3 source phrases per slide. Diagram labels must come from the source.
- Preserve source checkboxes and file-tree indentation. Keep comparison rows parallel. Make human judgment visible when it is the teaching point.

## Generation and saving

- Generate one slide per built-in imagegen call. Resolve the layout before calling; pass only this skill's fixed design, the chosen layout, exact source text, and necessary constraints.
- If a user supplies a design reference, inspect it and use it as a generation reference when supported and authorized. Do not claim to have a reference image when none is supplied.
- When saving is requested, choose a local temporary folder and a project output folder. Save the final image to both and verify file format, dimensions, and visual contents.
- Prefer the actual image path or artifact returned by the tool. If no usable file is returned, report the missing artifact and use only supported, authorized retrieval methods; do not assume a session-log format or scan unrelated logs.
- Do not switch to API/CLI, HTML screenshots, or PPTX exports merely to obtain a file. A fallback requires an explicit user request.

## Visual QA

All applicable checks below must pass:

- Exactly one slide, with a 16:9 canvas.
- Compare the rendered slide(s) with the outline's confirmed visible content item by item, including split-slide destinations. Every displayed source point, example, caveat, condition, step, comparison row, and required visual meaning remains readable and faithful. A prompt that contains the content is not proof that the image contains it.
- Check for scope leakage: no outside `###` slide-management heading or its heading wording, speaker-note prose, Markdown fences, or slide identifiers have been added as visible wording. If an outside heading was explicitly requested as the visible title, verify that inclusion against the confirmed display plan.
- Missing or meaning-altered source content fails QA even when the diagram is excellent. Restore the content and adjust the layout or split before delivery; do not accept the image for visual quality alone.
- Title, body, and source-provided takeaway have clear hierarchy and enough whitespace.
- Check illustration-to-text balance: ordinary explanatory scenes do not dominate the slide or squeeze complete explanations, sparse content has not caused unnecessary enlargement, and the source-required diagram and its connections remain prominent. Adjust artwork scale or placement and regenerate when needed; do not compensate by shrinking text or adding filler.
- Palette, typography, and divider match this skill's fixed design and the rest of the deck.
- When present, illustrations follow the fixed business-scene isometric style across the deck: consistent view, depth, edge treatment, detail density, light direction, and restrained shadows. In an illustrated action, relevant people, readable gestures, and tools make that action clear within user/source restrictions; recurring characters remain consistent. Text remains horizontal and front-facing, and diagram relationships stay clear. A complete structured reference may pass without scene artwork; text-only slides must satisfy their recorded exception.
- Review all slides at the same displayed width, then inspect each at roughly 960×540. Titles, explanations, and short labels must retain the same three size tiers across slides. Fail slides with visibly smaller body text, a fourth text size, compressed glyphs, or source explanations rendered as small diagram captions. Prompted pixel values alone do not establish a pass.
- Check that optional repeated diagram labels have not created visual noise or squeezed the original explanation. Whitespace and aligned text areas remain consistent without enlarging or shrinking the font to fill the slide.
- Compare the image with the visual plan: every required diagram or scene/object is actually present, readable, and depicts the planned source relationship or action. A connected process or aligned comparison must expose that relationship; decorative icons or paragraph cards alone do not pass. A scene/object must explain the source concept rather than merely decorate the slide.
- An ordinary explanation without its planned visual fails QA even if all words and colors are correct. Do not retroactively mark it `text-only` to accept the output. Any genuine plan change must still satisfy SKILL.md's exception criteria and explicit user/source instructions, then undergo QA again.
- Layout serves the teaching role; any visual explains content and contains no invented labels or unsupported relationships.
- No invented logos, watermarks, fake UI details, or extra text.

When a required visual is absent, explicitly correct its objects/actions, relationships, and placement in the prompt; do not only request “more visual”. When a check fails, revise the specific cause and regenerate the affected slide. Do not repeatedly retry unchanged prompts. If fidelity still fails, explain the unresolved issue and offer source-preserving splitting or a user-authorized alternative; do not present it as finished.

### Before deck delivery

Review all slides in scope at a common preview size against the visual plan. Check ordinary explanations for missing content-linked visuals, every text-only slide for its recorded exception, and repeated layouts for a drift into paragraph-only slides. Check large empty regions for unbalanced content placement, and crowded slides for visuals squeezing body text. Correct affected slides while keeping the fixed typography and source content. Final acceptance and packaging require all applicable visual checks to pass; report unresolved failures explicitly rather than delivering them as a completed deck.
